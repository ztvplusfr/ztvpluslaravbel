<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Administration - Éditer Film</title>
     <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <!-- Tabler Icons -->
    <link href="https://unpkg.com/tabler-icons@latest/iconfont/tabler-icons.min.css" rel="stylesheet">
 </head>
 <body class="bg-background text-white">
     <div class="min-h-screen flex">
         <!-- Sidebar Admin -->
         <aside class="w-64 h-screen bg-background p-6">
             <div class="mb-8 flex justify-center">
                 <img class="h-12 w-auto" src="<?php echo e(asset('brand/logo.png')); ?>" alt="Logo" />
             </div>
             <nav>
                 <ul>
                    <li>
                        <a href="<?php echo e(route('admin')); ?>" class="block flex items-center px-4 py-3 text-white hover:bg-gray-700 hover:text-primary rounded mb-2">
                            <i class="ti ti-home mr-3 text-2xl"></i>
                            <span class="text-lg">Accueil</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="block flex items-center px-4 py-3 text-white hover:bg-gray-700 hover:text-primary rounded mb-2">
                            <i class="ti ti-device-tv mr-3 text-2xl"></i> <span class="text-lg">Séries</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.movies')); ?>" class="block flex items-center px-4 py-3 text-white hover:bg-gray-700 hover:text-primary rounded mb-2">
                            <i class="ti ti-movie mr-3 text-2xl"></i> <span class="text-lg">Films</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.users')); ?>" class="block flex items-center px-4 py-3 text-white hover:bg-gray-700 hover:text-primary rounded mb-2">
                            <i class="ti ti-users mr-3 text-2xl"></i> <span class="text-lg">Utilisateurs</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="block flex items-center px-4 py-3 text-white hover:bg-gray-700 hover:text-primary rounded mb-2">
                            <i class="ti ti-world mr-3 text-2xl"></i> <span class="text-lg">Site</span>
                        </a>
                    </li>
                    <!-- Importer -->
                    <li>
                        <a href="<?php echo e(route('admin.import.form')); ?>" class="block flex items-center px-4 py-3 text-white hover:bg-gray-700 hover:text-primary rounded mb-2">
                            <i class="ti ti-upload mr-3 text-2xl"></i> <span class="text-lg">Importer</span>
                        </a>
                    </li>
                 </ul>
             </nav>
         </aside>
         <!-- Contenu principal -->
         <main class="flex-1 p-8 h-screen overflow-y-auto">
             <h1 class="text-3xl font-bold text-primary mb-6">Éditer le Film</h1>
             <p class="mb-4">Bienvenue, <?php echo e(Auth::user()->name); ?> ! Modifiez les informations du film ci-dessous.</p>

             <!-- Aperçu des images -->
             <div class="flex justify-center items-start space-x-8 mb-6">
                 <div>
                     <?php if($movie->backdrop_path): ?>
                     <img src="https://image.tmdb.org/t/p/w500<?php echo e($movie->backdrop_path); ?>" alt="Backdrop de <?php echo e($movie->title); ?>" class="w-80 h-45 object-cover rounded">
                     <?php else: ?>
                     <div class="w-80 h-45 bg-background border border-primary rounded flex items-center justify-center text-text">Aucun Backdrop</div>
                     <?php endif; ?>
                 </div>
                 <div>
                     <?php if($movie->poster_path): ?>
                     <img src="https://image.tmdb.org/t/p/w342<?php echo e($movie->poster_path); ?>" alt="Poster de <?php echo e($movie->title); ?>" class="w-40 h-60 object-cover rounded">
                     <?php else: ?>
                     <div class="w-40 h-60 bg-background border border-primary rounded flex items-center justify-center text-text">Aucun Poster</div>
                     <?php endif; ?>
                 </div>
             </div>

             <h2 class="text-2xl font-bold text-primary mb-6"><?php echo e($movie->title); ?></h2>

             <!-- Action Buttons -->
             <div class="mb-6 flex space-x-4">
                 <a href="/movies/<?php echo e($movie->id); ?>" target="_blank" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Voir la fiche du film</a>
                 <a href="/play/movies/<?php echo e($movie->id); ?>" target="_blank" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Regarder le film</a>
             </div>

             <form action="/admin/movies/<?php echo e($movie->id); ?>" method="POST" class="bg-background p-6 rounded-lg border border-primary">
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PUT'); ?>

                 <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div>
                         <label for="tmdb_id" class="block text-sm font-medium text-text">TMDB ID</label>
                         <input type="number" id="tmdb_id" name="tmdb_id" value="<?php echo e($movie->tmdb_id); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text" readonly>
                     </div>

                     <div>
                         <label for="title" class="block text-sm font-medium text-text">Titre</label>
                         <input type="text" id="title" name="title" value="<?php echo e($movie->title); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text" required>
                     </div>

                     <div>
                         <label for="original_title" class="block text-sm font-medium text-text">Titre Original</label>
                         <input type="text" id="original_title" name="original_title" value="<?php echo e($movie->original_title); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="language" class="block text-sm font-medium text-text">Langue</label>
                         <input type="text" id="language" name="language" value="<?php echo e($movie->language); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="release_date" class="block text-sm font-medium text-text">Date de Sortie</label>
                         <input type="date" id="release_date" name="release_date" value="<?php echo e($movie->release_date ? $movie->release_date->format('Y-m-d') : ''); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="genres" class="block text-sm font-medium text-text">Genres (séparés par des virgules)</label>
                         <input type="text" id="genres" name="genres" value="<?php echo e($movie->genres ? implode(', ', $movie->genres) : ''); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="poster_path" class="block text-sm font-medium text-text">URL Poster</label>
                         <input type="url" id="poster_path" name="poster_path" value="<?php echo e($movie->poster_path); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="backdrop_path" class="block text-sm font-medium text-text">URL Backdrop</label>
                         <input type="url" id="backdrop_path" name="backdrop_path" value="<?php echo e($movie->backdrop_path); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="popularity" class="block text-sm font-medium text-text">Popularité</label>
                         <input type="number" step="0.01" id="popularity" name="popularity" value="<?php echo e($movie->popularity); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="vote_average" class="block text-sm font-medium text-text">Note Moyenne</label>
                         <input type="number" step="0.1" id="vote_average" name="vote_average" value="<?php echo e($movie->vote_average); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div>
                         <label for="vote_count" class="block text-sm font-medium text-text">Nombre de Votes</label>
                         <input type="number" id="vote_count" name="vote_count" value="<?php echo e($movie->vote_count); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text">
                     </div>

                     <div class="flex items-center">
                         <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e($movie->is_active ? 'checked' : ''); ?> class="h-4 w-4 text-primary bg-background border-primary rounded">
                         <label for="is_active" class="ml-2 block text-sm text-text">Actif</label>
                     </div>
                 </div>

                 <div class="mt-6">
                     <label for="overview" class="block text-sm font-medium text-text">Synopsis</label>
                     <textarea id="overview" name="overview" rows="4" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text"><?php echo e($movie->overview); ?></textarea>
                 </div>

                 <div class="mt-6">
                     <label for="trailer_id" class="block text-sm font-medium text-text">ID Trailer YouTube</label>
                     <input type="text" id="trailer_id" name="trailer_id" value="<?php echo e($movie->trailer_id); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text" placeholder="Ex: dQw4w9WgXcQ">
                 </div>

                 <div class="mt-6">
                     <label for="age_rating" class="block text-sm font-medium text-text">Classification d'Âge</label>
                     <input type="text" id="age_rating" name="age_rating" value="<?php echo e($movie->age_rating); ?>" class="mt-1 block w-full px-3 py-2 bg-background border border-primary rounded-md text-text" placeholder="Ex: 12 ans">
                 </div>

                 <div class="mt-6 flex justify-end space-x-4">
                     <a href="<?php echo e(route('admin.movies')); ?>" class="bg-background text-text px-4 py-2 rounded border border-primary hover:bg-primary hover:text-background">Annuler</a>
                     <button type="submit" class="bg-primary text-background px-4 py-2 rounded hover:bg-opacity-80">Sauvegarder</button>
                 </div>
             </form>

             <!-- Section Vidéos -->
             <div class="mt-12">
                 <h2 class="text-2xl font-bold text-primary mb-4">Vidéos</h2>
                 <table class="w-full text-left border-collapse border border-primary">
                     <thead>
                         <tr>
                             <th class="border border-primary px-4 py-2">Serveur</th>
                             <th class="border border-primary px-4 py-2">Langue</th>
                             <th class="border border-primary px-4 py-2">Qualité</th>
                             <th class="border border-primary px-4 py-2">Sous-titre</th>
                             <th class="border border-primary px-4 py-2">Actif</th>
                             <th class="border border-primary px-4 py-2">Actions</th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php $__empty_1 = true; $__currentLoopData = $movie->videos ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                         <tr>
                             <td class="border border-primary px-4 py-2"><?php echo e($video->server_name); ?></td>
                             <td class="border border-primary px-4 py-2"><?php echo e($video->language); ?></td>
                             <td class="border border-primary px-4 py-2"><?php echo e($video->quality); ?></td>
                             <td class="border border-primary px-4 py-2"><?php echo e($video->subtitle ?? 'Aucun'); ?></td>
                             <td class="border border-primary px-4 py-2"><?php echo e($video->is_active ? 'Oui' : 'Non'); ?></td>
                             <td class="border border-primary px-4 py-2">
                                 <a href="<?php echo e(route('admin.movies.videos.edit', ['movie' => $movie->id, 'video' => $video->id])); ?>" class="text-primary hover:underline">Modifier</a>
                                 <form action="<?php echo e(route('admin.movies.videos.destroy', ['movie' => $movie->id, 'video' => $video->id])); ?>" method="POST" class="inline">
                                     <?php echo csrf_field(); ?>
                                     <?php echo method_field('DELETE'); ?>
                                     <button type="submit" class="text-red-500 hover:underline">Supprimer</button>
                                 </form>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <tr>
                             <td colspan="6" class="border border-primary px-4 py-2 text-center">Aucune vidéo disponible.</td>
                         </tr>
                         <?php endif; ?>
                     </tbody>
                 </table>

                 <div class="mt-4">
                     <a href="<?php echo e(route('admin.movies.videos.create', ['movie' => $movie->id])); ?>" class="bg-primary text-background px-4 py-2 rounded hover:bg-opacity-80">Ajouter une Vidéo</a>
                 </div>
             </div>
         </main>
     </div>
 </body>
</html><?php /**PATH C:\Users\Hiro\ztvplusfr\resources\views/admin/movies/edit.blade.php ENDPATH**/ ?>